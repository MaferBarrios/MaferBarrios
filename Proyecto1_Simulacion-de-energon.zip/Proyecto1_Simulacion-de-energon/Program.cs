﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba_Proyecto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Inicio
            //Declarar variables
            String nombre;
            String modo = "robot";
            int energon, posicioninicial;

            //Ingreso de datos
            Console.WriteLine("Ingrese su nombre: ");
            nombre = Console.ReadLine();

            Console.WriteLine("\nIngrese el modo: (a) para auto, (c) para camion, (m) para moto");
            modo = Console.ReadLine();

            Console.WriteLine("\nIngrese el nivel de energon (0% al 100%): ");
            energon = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nIngrese la posicion Inicial (km de distancia de la base): ");
            posicioninicial = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nPresione cualquier tecla para ver el menu");

            Console.ReadKey();

            String opcion;

            do
            {
                //Visualización del menú
                Console.Clear();
                Console.WriteLine("--M--E--N--U--\n" +
                                  "\n1. Ver informacion sobre robot" +
                                  "\n2. Cargar Energon" +
                                  "\n3. Transformar" +
                                  "\n4. Moverse" +
                                  "\n5. Salir\n");

                opcion = Console.ReadLine();

                switch (opcion)
                {
                    //Opción 1 está mostrando los datos
                    case "1":

                        Console.WriteLine("\n¡MOSTRANDO DATOS!\n");
                        Console.WriteLine("Su nombre es: " + nombre);
                        Console.WriteLine("Su nivel de energon es: " + energon + "%");
                        Console.WriteLine("Te encuentras en la posicion: " + posicioninicial + "km");
                        //Este IF está leyendo la variable modo como Vehículo o Robot
                        if (modo == "a" || modo == "c" || modo == "m" || modo == "vehiculo")
                        {
                            Console.WriteLine("Te encuentras en modo: Vehiculo");
                            modo = "vehiculo";

                        }
                        else if (modo == "robot")
                        {
                            Console.WriteLine("Te encuentras en modo: robot");
                            modo = "robot";
                        }

                        break;
                    //Opción 2 está incrementando un 5% el energon que el usuario ingresó
                    case "2":
                        if (energon < 95)
                        {
                            energon = energon + 5;
                            Console.WriteLine("\n¡INCREMENTADO TU NIVEL DE ENERGON EN UN 5%!");
                            Console.WriteLine("tu nivel de energon actual es: " + energon + "%");
                        }
                        else if (energon >= 100)
                        {
                            Console.WriteLine("Cuentas con suficiente energon, puedes movilizarte en la opcion 4");
                        }
                        break;
                    //Opción 3 está transformando el modo, si estaba en robot pasa a vehículo y viceversa
                    case "3":
                        Console.WriteLine("\n¡TRANSFORMANDO EL MODO ACTUAL!");

                        if (modo == "robot")
                        {
                            modo = "vehiculo";
                            Console.WriteLine("Ahora te encuentras en modo vehículo");
                        }
                        else if (modo == "a" || modo == "c" || modo == "m" || modo == "vehiculo")
                        {
                            modo = "robot";
                            Console.WriteLine("Ahora te encuentras en modo robot");
                        }
                        break;
                    //Opción 4 va a pedir las horas para movilizarse luego mostrará el recorrido y el energon gastado
                    case "4":
                        int horas;
                        Console.WriteLine("Escriba las horas que desea movilizarse");
                        horas = Convert.ToInt32(Console.ReadLine());
                    //Utilizamos la variable modo para clasificar en que tipo de modo se encuentra y los parámetros establecidos
                        switch (modo)
                        {
                            //En caso que el modo sea robot realizará los cálculos pertinentes
                            case "robot":
                                int Gasto_Energo_Hora_robot = 5;
                                int Cantidad_Energon_necesario = horas * Gasto_Energo_Hora_robot;

                                if (energon < Cantidad_Energon_necesario)
                                {
                                    Console.WriteLine("No tienes suficiente energon, para recargar ve a la opcion 2");
                                }
                                else
                                {
                                    Console.WriteLine("¡MOVIENDOSE!");

                                    int velocidad_robot = 50;

                                    for (int i = 1; i <= horas; i++)
                                    {
                                        posicioninicial += velocidad_robot;
                                        energon -= Gasto_Energo_Hora_robot;
                                        Console.WriteLine("Hora " + i + ", robot se encuentra en la posición " + posicioninicial + "km y cuenta con " + energon + "% de energon");
                                    }
                                }
                                break;
                            //En caso que el modo sea vehículo, acá debe preguntar el modo alterno 
                            case "vehiculo":
                                Console.WriteLine("Ingresa el tipo de vehiculo en modo alterno en el que te encuentras: (a) auto, (c) camion, (m) moto");
                                modo = Console.ReadLine();
                                if (modo == "a")
                                {
                                    int Gasto_Energo_Hora_auto = 10;
                                    Cantidad_Energon_necesario = horas * Gasto_Energo_Hora_auto;

                                    if (energon < Cantidad_Energon_necesario)
                                    {
                                        Console.WriteLine("No tienes suficiente energon, para recargar ve a la opcion 2");
                                    }
                                    else
                                    {
                                        Console.WriteLine("¡MOVIENDOSE!");

                                        int velocidad_auto = 110;

                                        for (int i = 1; i <= horas; i++)
                                        {
                                            posicioninicial += velocidad_auto;

                                            energon -= Gasto_Energo_Hora_auto;
                                            Console.WriteLine("Hora " + i + ", auto se encuentra en la posición " + posicioninicial + "km y cuenta con " + energon + "% de energon");
                                        }
                                    }
                                }
                                else if (modo == "c")
                                {
                                    int Gasto_Energo_Hora_camion = 25;
                                    Cantidad_Energon_necesario = horas * Gasto_Energo_Hora_camion;

                                    if (energon < Cantidad_Energon_necesario)
                                    {
                                        Console.WriteLine("No tienes suficiente energon, para recargar ve a la opcion 2");
                                    }
                                    else
                                    {
                                        Console.WriteLine("¡MOVIENDOSE!");

                                        int velocidad_camion = 85;

                                        for (int i = 1; i <= horas; i++)
                                        {
                                            posicioninicial += velocidad_camion;
                                            energon -= Gasto_Energo_Hora_camion;
                                            Console.WriteLine("Hora " + i + ", camion se encuentra en la posición " + posicioninicial + "km y cuenta con " + energon + "% de energon");
                                        }
                                    }
                                }
                                else if (modo == "m")
                                {
                                    int Gasto_Energo_hora_moto = 20;
                                    Cantidad_Energon_necesario = horas * Gasto_Energo_hora_moto;

                                    if (energon < Cantidad_Energon_necesario)
                                    {
                                        Console.WriteLine("No tienes suficiente energon, para recargar ve a la opcion 2");
                                    }
                                    else
                                    {
                                        Console.WriteLine("¡MOVIENDOSE!");

                                        int velocidad_moto = 120;

                                        for (int i = 1; i <= horas; i++)
                                        {
                                            posicioninicial += velocidad_moto;
                                            energon -= Gasto_Energo_hora_moto;
                                            Console.WriteLine("Hora " + i + ", moto se encuentra en la posición " + posicioninicial + "km y cuenta con " + energon + "% de energon");
                                        }
                                    }
                                }
                                break;
                            //En caso que el modo se encuentre en "a" porque el usuario accedió directamente a la opción 4
                            case "a":
                                int Gasto_Energo_hora_auto = 10;
                                Cantidad_Energon_necesario = horas * Gasto_Energo_hora_auto;

                                if (energon < Cantidad_Energon_necesario)
                                {
                                    Console.WriteLine("No tienes suficiente energon, para recargar ve a la opcion 2");
                                }
                                else
                                {
                                    Console.WriteLine("¡MOVIENDOSE!");

                                    int velocidad_auto = 110;

                                    for (int i = 1; i <= horas; i++)
                                    {
                                        posicioninicial += velocidad_auto;
                                        energon -= Gasto_Energo_hora_auto;
                                        Console.WriteLine("Hora " + i + ", auto se encuentra en la posición " + posicioninicial + "km y cuenta con " + energon + "% de energon");
                                    }
                                }
                                break;
                            //En caso que el modo se encuentre en "c" porque el usuario accedió directamente a la opción 4
                            case "c":
                                int Gasto_Energo_hora_camion = 25;
                                Cantidad_Energon_necesario = horas * Gasto_Energo_hora_camion;

                                if (energon < Cantidad_Energon_necesario)
                                {
                                    Console.WriteLine("No tienes suficiente energon, para recargar ve a la opcion 2");
                                }
                                else
                                {
                                    Console.WriteLine("¡MOVIENDOSE!");

                                    int velocidad_camion = 85;

                                    for (int i = 1; i <= horas; i++)
                                    {
                                        posicioninicial += velocidad_camion;
                                        energon -= Gasto_Energo_hora_camion;
                                        Console.WriteLine("Hora " + i + ", camion se encuentra en la posición " + posicioninicial + "km y cuenta con " + energon + "% de energon");
                                    }
                                }
                                break;
                            //En caso que el modo se encuentre en "m" porque el usuario accedió directamente a la opción 4
                            case "m":
                                int Gasto_Energo_Hora_moto = 20;
                                Cantidad_Energon_necesario = horas * Gasto_Energo_Hora_moto;

                                if (energon < Cantidad_Energon_necesario)
                                {
                                    Console.WriteLine("No tienes suficiente energon, para recargar ve a la opcion 2");
                                }
                                else
                                {
                                    Console.WriteLine("¡MOVIENDOSE!");

                                    int velocidad_moto = 120;

                                    for (int i = 1; i <= horas; i++)
                                    {
                                        posicioninicial += velocidad_moto;
                                        energon -= Gasto_Energo_Hora_moto;
                                        Console.WriteLine("Hora " + i + ", moto se encuentra en la posición " + posicioninicial + "km y cuenta con " + energon + "% de energon");
                                    }
                                }
                                break;

                        }

                        break;
                    //Opcion 5 el programa terminará
                    case "5":
                        Console.WriteLine("\n¡Gracias! por utilizar nuestro simulador.");
                        break;

                    default:
                        Console.WriteLine("No es válida esa opción, por favor escoge una de las que se muestran en el menu.");
                        break;
                }

                Console.WriteLine("\nPresione cualquier tecla para continuar");
                Console.ReadKey();
                Console.Clear();

            } while (opcion != "5");

            //Salida
            Console.ReadKey();
        }
    }
}
